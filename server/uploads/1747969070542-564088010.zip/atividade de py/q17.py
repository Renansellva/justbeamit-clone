nome = "Maria"

mensagem1 = "Olá " + nome + ", bem-vinda!"
print(mensagem1)

mensagem2 = f"Olá {nome}, bem-vinda!"
print(mensagem2)
