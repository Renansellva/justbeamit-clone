while True:
    print("\nMenu:")
    print("1 - Cadastrar nome e idade")
    print("2 - Calcular IMC")
    print("3 - Sair")
    opcao = input("Escolha uma opção: ")

    if opcao == "1":
        nome = input("Nome: ")
        idade = input("Idade: ")
        print(f"Nome: {nome}, Idade: {idade}")
    elif opcao == "2":
        peso = float(input("Peso (kg): "))
        altura = float(input("Altura (m): "))
        imc = peso / (altura ** 2)
        print(f"IMC: {imc:.2f}")
    elif opcao == "3":
        print("Saindo...")
        break
    else:
        print("Opção inválida!")
