senha_correta = "1234"
senha = input("Digite a senha: ")

if senha != senha_correta:
    print("Senha incorreta.")
else:
    print("Acesso permitido.")
