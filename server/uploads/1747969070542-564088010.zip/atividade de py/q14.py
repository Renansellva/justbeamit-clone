valor = 23.4567

print(f"Valor com f-string: {valor:.2f}")

print("Valor com %%: %.2f" % valor)

