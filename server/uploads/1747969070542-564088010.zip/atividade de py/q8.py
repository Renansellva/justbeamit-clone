nome = "Lucas"
nota = 9.75
idade = 20
codigo = 255

print("Aluno: %s, Nota: %.2f, Idade: %d, Código: %08X" % (nome, nota, idade, codigo))
