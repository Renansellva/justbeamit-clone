numero = int(input("Digite um número: "))

print("Maior que 10?", numero > 10)
print("Igual a 0?", numero == 0)
print("Divisível por 2?", numero % 2 == 0)
