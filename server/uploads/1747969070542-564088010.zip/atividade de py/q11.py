nome = input("Digite seu nome: ")
idade = int(input("Digite sua idade: "))
altura = float(input("Digite sua altura: "))

print("Tipo do nome:", type(nome))
print("Tipo da idade:", type(idade))
print("Tipo da altura:", type(altura))
