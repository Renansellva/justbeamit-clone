frase = input("Digite uma frase: ")
palavra = input("Digite uma palavra: ")

if palavra in frase:
    print("A palavra está na frase.")
else:
    print("A palavra NÃO está na frase.")
