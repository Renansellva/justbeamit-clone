cliente = "João"
produto = "bicicleta"
valor = 1500.00

print("O cliente {} comprou uma {} por R${:.2f}".format(cliente, produto, valor))
