a = 10
b = 3

print(f"Divisão: {a / b:.2f}")
print(f"Divisão inteira: {a // b}")
print(f"Resto da divisão: {a % b:.2f}")
