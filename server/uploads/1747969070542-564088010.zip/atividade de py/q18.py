nota = float(input("Digite uma nota de 0 a 10: "))

if 0 <= nota < 5:
    print("Insuficiente")
elif 5 <= nota < 8:
    print("Média")
elif 8 <= nota <= 10:
    print("Excelente")
else:
    print("Nota inválida")
