idade = int(input("Digite sua idade: "))
maioridade = idade >= 18
print("Maior de idade?", maioridade)
