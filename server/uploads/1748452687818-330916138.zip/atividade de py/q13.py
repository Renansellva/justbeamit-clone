nome = input("Digite um nome: ")

if nome.lower().startswith('a'):
    print("Começa com a letra A")
else:
    print("Não começa com a letra A")
