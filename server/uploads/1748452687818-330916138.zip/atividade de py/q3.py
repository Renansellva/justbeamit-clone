nome = input("Digite seu nome: ")
sobrenome = input("Digite seu sobrenome: ")

print(f"Nome completo: {nome} {sobrenome}")

print("Nome completo: {} {}".format(nome, sobrenome))
