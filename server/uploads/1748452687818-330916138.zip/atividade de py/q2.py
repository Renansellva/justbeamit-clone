nome = input("Digite seu nome: ")
sobrenome = input("Digite seu sobrenome: ")

nome_completo = nome + " " + sobrenome
print("Nome completo:", nome_completo)
print("Nome repetido 3 vezes:", (nome + " ") * 3)
